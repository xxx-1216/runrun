package com.uc.web;

import com.google.gson.Gson;
import com.uc.pojo.User;
import com.uc.service.UserService;
import com.uc.service.impl.UserServiceImpl;
import com.uc.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class UserServlet extends BaseServlet{
    UserService userService=new UserServiceImpl();

    //登录
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        //获取请求的用户名和密码
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        User loginUser= userService.login(new User(null, null,username, password,null, null));
       /* //创建Gson对象实例
        Gson gson=new Gson();
        //JavaBean对象转为Json字符串
        String loginJsonString=gson.toJson(loginUser);*/
        if(loginUser==null){
            //登录失败 返回错误码
            out.print("fail");
        }
        else {
            //登录成功 返回身份
            out.print(loginUser.getIdentity());
        }
        out.flush();
        out.close();
    }

    //注册
    protected void register(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        //获取请求数据
        String name=req.getParameter("name");
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String identity=req.getParameter("identity");
        String place=req.getParameter("place");
        User registerUser= WebUtils.paramToBean(req.getParameterMap(),new User());

        //检查用户名是否已存在
        //用户名已存在->注册失败
        if(userService.existUsername(username)){
            out.print(username);
        }
        //用户名不存在->注册成功
        else if(!userService.existUsername(username)){
            userService.register(new User(null,name,username,password,identity,place));
            out.print("success");
        }
        //其他情况：注册失败
        else{
            out.print("fail");
        }
        out.flush();
        out.close();
    }
}
