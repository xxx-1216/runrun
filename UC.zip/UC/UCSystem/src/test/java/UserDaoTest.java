import com.uc.dao.UserDao;
import com.uc.dao.impl.UserDaoImpl;
import com.uc.pojo.User;
import org.junit.Test;

public class UserDaoTest {
    UserDao userdao=new UserDaoImpl();

    @Test
    public void queryUserByUsername() {
        if(userdao.queryUserByUsername("admin")==null){
            System.out.println("用户名可用");
        }else{
            System.out.println("用户名已存在");
        }
    }

    @Test
    public void queryUserByUsernameAndPassword() {
        if(userdao.queryUserByUsernameAndPassword("admin","admin")==null){
            System.out.println("登陆失败");
        }else{
            System.out.println("登录成功");
        }
    }

    @Test
    public void saveUser() {
        System.out.println(userdao.saveUser(new User(null,"陈尚萱","admin1","1234","A","浙江杭州")));
    }
}
