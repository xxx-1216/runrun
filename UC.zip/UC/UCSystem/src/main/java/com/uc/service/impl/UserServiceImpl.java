package com.uc.service.impl;

import com.uc.dao.UserDao;
import com.uc.dao.impl.UserDaoImpl;
import com.uc.pojo.User;
import com.uc.service.UserService;

public class UserServiceImpl implements UserService {
    private UserDao userDao=new UserDaoImpl();

    @Override
    public User login(User user) {
        return userDao.queryUserByUsernameAndPassword(user.getUsername(), user.getPassword());
    }

    @Override
    public void register(User user) {
        userDao.saveUser(user);
    }

    @Override
    public boolean existUsername(String username) {
        if(userDao.queryUserByUsername(username)==null){
            return false;
        }
        else{
            return true;
        }
    }
}
