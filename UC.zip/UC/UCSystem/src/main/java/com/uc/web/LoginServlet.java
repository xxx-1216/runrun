package com.uc.web;

import com.uc.pojo.User;
import com.uc.service.UserService;
import com.uc.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends BaseServlet{
    UserService userService=new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        //获取请求的用户名和密码
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        User loginUser= userService.login(new User(null,null, username, password, null,null));
        if(loginUser==null){
            //登录失败 返回错误码
            out.print("fail");
            //out.print(loginUser.getUsername());
        }
        else {
            //登录成功 返回身份
            out.print(loginUser.getIdentity());
        }
        out.flush();
        out.close();
    }
}
