package com.uc.utils;

import org.apache.commons.beanutils.BeanUtils;

import java.util.Map;

public class WebUtils {
    //将Map中的值注入对应的JavaBean的属性中
    //使用泛型省去Object到User的类型转换
    public static <T> T paramToBean(Map value,T bean){
        //将请求参数注入user对象
        try {
            BeanUtils.populate(bean,value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bean;
    }
}
