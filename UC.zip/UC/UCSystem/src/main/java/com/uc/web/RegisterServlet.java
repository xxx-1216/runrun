package com.uc.web;

import com.uc.pojo.User;
import com.uc.service.UserService;
import com.uc.service.impl.UserServiceImpl;
import com.uc.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class RegisterServlet extends BaseServlet{
    UserService userService=new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        //获取请求数据
        String name=java.net.URLDecoder.decode(req.getParameter("name"),"UTF-8");
        name= java.net.URLDecoder.decode(name, "UTF-8");
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String identity=req.getParameter("identity");
        String place=java.net.URLDecoder.decode(req.getParameter("place"),"UTF-8");
        System.out.println(place);
        place= java.net.URLDecoder.decode(place, "UTF-8");
        System.out.println(place);
        User registerUser= WebUtils.paramToBean(req.getParameterMap(),new User());

        //检查用户名是否已存在
        //用户名已存在->注册失败
        if(userService.existUsername(username)){
            out.print(username);
        }
        //用户名不存在->注册成功
        else if(!userService.existUsername(username)){
            userService.register(new User(null,name,username,password,identity,place));
            out.print("success");
            //out.print(registerUser.getUsername());
        }
        //其他情况：注册失败
        else{
            out.print("fail");
        }
        out.flush();
        out.close();
    }
}
