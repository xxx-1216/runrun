package com.uc.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

public class JdbcUtils {
    private static DruidDataSource dataSource;

    //静态代码块:类加载的时候自动执行静态代码块且只执行一次
    static{
        try {
        //加载配置文件
        Properties properties=new Properties();
        InputStream inputStream=JdbcUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
        //从流中加载数据
        properties.load(inputStream);
        //创建数据库连接池
        dataSource= (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //获取数据库连接池对象
    public static Connection getConnection(){
        Connection conn=null;
        try {
            conn=dataSource.getConnection();
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
        return conn;
    }

    //关闭连接
    public static void close(Connection conn){
        if(conn!=null){
            try {
                conn.close();
            } catch (Exception throwables) {
                throwables.printStackTrace();
            }
        }
    }
}