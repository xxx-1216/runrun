import com.uc.pojo.User;
import com.uc.service.UserService;
import com.uc.service.impl.UserServiceImpl;
import org.junit.Test;

public class UserServiceTest {
    UserService userService=new UserServiceImpl();

    @Test
    public void register() {
        userService.register(new User(null,"陈尚萱","chen","123456","1","浙江杭州"));
    }

    @Test
    public void login() {
        System.out.println(userService.login(new User(null,null,"admin","admin",null,null)));
    }

    @Test
    public void existUsername() {
        if(userService.existUsername("chen")){
            System.out.println("用户名已存在");
        }else{
            System.out.println("用户名可用");
        }
    }

}
