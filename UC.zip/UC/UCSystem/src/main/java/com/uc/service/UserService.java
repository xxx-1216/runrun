package com.uc.service;

import com.uc.pojo.User;

public interface UserService {
    //登录
    public User login(User user);

    //注册
    public void register(User user);

    //检查用户名是否可用
    //return：true:用户名存在 false:用户名可用
    public boolean existUsername(String username);
}
